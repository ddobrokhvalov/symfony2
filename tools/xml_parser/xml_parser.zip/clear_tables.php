<?php
	$host="10.32.17.6";
	//$host="localhost";
	$user="employe";
	$pwd="Oongee6m";
	$db=mysql_connect($host,$user,$pwd) or die("Could not connect: " . mysql_error().'\n');
	mysql_select_db("employe",$db);
	
	//$fh = fopen(dirname(__FILE__).'/logs/export.log', "a+");
	//var_dump(dirname(__FILE__).'/logs/export.log');
	$result0 = mysql_query ("delete from employees");
	$result00 = mysql_query ("delete from employees_history");